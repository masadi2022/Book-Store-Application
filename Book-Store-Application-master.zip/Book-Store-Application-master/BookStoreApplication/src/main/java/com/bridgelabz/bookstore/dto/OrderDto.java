package com.bridgelabz.bookstore.dto;

import lombok.Data;

@Data
public class OrderDto {
	
	private Long orderId;
	
	private String orderStatus;
	

//	private List<Quantity> QuantityOfBooks;
//	
//	private List<Book> BooksList;

}
