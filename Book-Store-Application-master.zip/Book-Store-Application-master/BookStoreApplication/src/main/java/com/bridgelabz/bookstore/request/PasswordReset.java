/**
 * 
 */
package com.bridgelabz.bookstore.request;

/**
 * @author HP
 *
 */
public class PasswordReset {
	private String email;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
