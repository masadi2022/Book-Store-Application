package com.bridgelabz.bookstore.dto;

import lombok.Data;

@Data
public class RatingReviewDTO {

	private Integer rating;
	
	private String review;
	
}
